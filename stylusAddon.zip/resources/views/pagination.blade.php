<div class="row tm-mb-90">
    <div class="col-12 d-flex justify-content-between align-items-center tm-paging-col">
        {{-- <a href="javascript:void(0);" class="btn btn-primary tm-btn-prev mb-2 disabled">Previous</a>
        <div class="tm-paging d-flex">
            <a href="javascript:void(0);" class="tm-paging-link ">1</a>
            <a href="javascript:void(0);" class="tm-paging-link ">2</a>
            <a href="javascript:void(0);" class="tm-paging-link ">3</a>
            <a href="javascript:void(0);" class="tm-paging-link ">4</a>
        </div>
        <a href="javascript:void(0);" class="btn btn-primary tm-btn-next">Next Page</a> --}}
        {{$paginator}}
    </div>
</div>

