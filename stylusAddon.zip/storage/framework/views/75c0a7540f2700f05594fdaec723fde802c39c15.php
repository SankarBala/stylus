

<?php $__env->startSection('content'); ?>

    <div class="row mb-4">
        <h2 class="col-6 tm-text-primary">
            Latest Styles
        </h2>
        <div class="col-6 d-flex justify-content-end align-items-center">
            <form action="" method="GET" class="tm-text-primary">
                Page <input type="number" value="<?php echo e($styles->currentPage()); ?>" name="page" size="1"
                    class="tm-input-paging tm-text-primary"> of
                <?php echo e($styles->lastPage()); ?>

            </form>
        </div>
    </div>
    <div class="row tm-mb-90 tm-gallery">

        <?php $__currentLoopData = $styles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $style): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
                <figure class="effect-ming tm-video-item">
                    
                    <img src="<?php echo e($style->image); ?>" alt="Image" class="img-fluid" width="100%" height="100px">
                    <figcaption class="d-flex align-items-center justify-content-center">
                        <h2><?php echo e($style->name); ?></h2>
                        <a href="<?php echo e(route('styleDetails', $style)); ?>">View more</a>
                    </figcaption>
                </figure>
                <div class="d-flex justify-content-between tm-text-gray">
                    <span class="tm-text-gray-light text-danger">
                        <i class="fa fa-heart" aria-hidden="true"></i>
                        <?php echo e($style->subscription); ?></span>
                    <span>
                        <a href="<?php echo e(route('styleDownload', $style)); ?>" class="text-info"><i class="fa fa-download"
                                aria-hidden="true"></i>
                            Download</span></a>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div> <!-- row -->

    <?php echo e($styles->links('pagination')); ?>


    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\stylusAddon\resources\views/frontend/styles.blade.php ENDPATH**/ ?>