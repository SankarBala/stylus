




<?php $__env->startSection('content'); ?>
    <div class="row mb-4">
        <h2 class="col-12 tm-text-primary mb-3">Details about the style</h2>
        <hr />
    </div>
    <div class="row tm-mb-90">
        <div class="col-xl-8 col-lg-7 col-md-6 col-sm-12">
            
            <img src="<?php echo e($style->image); ?>" alt="Image" class="img-fluid" width="100%" height="100%">
        </div>
        <div class="col-xl-4 col-lg-5 col-md-6 col-sm-12">
            <div class="tm-bg-gray tm-video-details">
                <div class="mb-4">
                    <h3 class="tm-text-gray-dark mb-3">License</h3>
                    <h2 class="<?php echo e($style->subscription == 'free' ? 'text-success' : 'text-info'); ?>">
                        <?php echo e($style->subscription); ?>

                    </h2>
                    <p>Free and premium both are only for personal use. Do not share or sell.
                    </p>
                </div>
                <div class="text-center mb-5">
                    <a href="<?php echo e(route('styleDownload', $style)); ?>" class="btn btn-primary tm-btn-big">Download</a>
                </div>
                <div class="mb-4 d-flex flex-wrap justify-content-between">
                    <div class="mr-4 mb-2">
                        <span class="tm-text-gray-dark">Size: </span><span class="tm-text-primary"><?php echo e(ceil(strlen($style->content)/1000)); ?> KB</span>
                    </div>
                    <div class="mr-4 mb-2">
                        <span class="tm-text-gray-dark">Format: </span><span class="tm-text-primary">CSS</span>
                    </div>
                </div>
                <div>
                    <h3 class="tm-text-gray-dark mb-3">Applied to</h3>
                    <ul>
                        <?php
                            preg_match_all('/(domain|regexp|url-prefix|url)\(".+?"\)/', $style->content, $matches);
                        ?>

                        <?php $__currentLoopData = $matches[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <p><?php echo e($match); ?></p>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="row mb-4">
        <h2 class="col-12 tm-text-primary">
            Suggested styles
        </h2>
    </div>
    <div class="row mb-3 tm-gallery">

       <?php $__currentLoopData = $suggestion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suggested): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
        <figure class="effect-ming tm-video-item">
            
            <img src="<?php echo e($suggested->image); ?>" alt="Image" class="img-fluid">
            <figcaption class="d-flex align-items-center justify-content-center">
                <h2><?php echo e($suggested->name); ?></h2>
                <a href="<?php echo e(route('styleDetails', $suggested)); ?>">View more</a>
            </figcaption>
        </figure>
        <div class="d-flex justify-content-between tm-text-gray">
            <span class="tm-text-gray-light text-danger">
                <i class="fa fa-heart" aria-hidden="true"></i>
                <?php echo e($suggested->subscription); ?></span>
            <span>
                <a href="<?php echo e(route('styleDownload', $suggested)); ?>" class="text-info"><i class="fa fa-download" aria-hidden="true"></i>
                     Download</span></a>
        </div>
    </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       

    </div> <!-- row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\stylusAddon\resources\views/frontend/details.blade.php ENDPATH**/ ?>