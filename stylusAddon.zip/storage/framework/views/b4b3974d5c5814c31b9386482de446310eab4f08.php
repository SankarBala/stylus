<div class="row tm-mb-90">
    <div class="col-12 d-flex justify-content-between align-items-center tm-paging-col">
        
        <?php echo e($paginator); ?>

    </div>
</div>

<?php /**PATH D:\Laravel\stylusAddon\resources\views/pagination.blade.php ENDPATH**/ ?>