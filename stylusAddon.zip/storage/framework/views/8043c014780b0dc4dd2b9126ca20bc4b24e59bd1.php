

<?php $__env->startSection('title', 'Welcome'); ?>

<?php $__env->startSection('pageTitle', 'Dashboard'); ?>

<?php $__env->startSection('contentHeader'); ?>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Styles</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.style.create')); ?>">Create new style</a></li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <div class="row tm-mb-90 tm-gallery">
            <?php $__currentLoopData = $styles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $style): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
                    <figure class="effect-ming tm-video-item">
                        
                        <img src="<?php echo e($style->image); ?>" alt="Image" class="img-fluid" height="200px">
                        <figcaption class="d-flex align-items-center justify-content-center">
                            <h2><?php echo e($style->name); ?></h2>
                            <a href="<?php echo e(route('admin.style.show', $style)); ?>">View more</a>
                        </figcaption>
                    </figure>
                    <div class="d-flex justify-content-between tm-text-gray">
                        <span
                            class="tm-text-gray-light <?php echo e($style->subscription == 'premium' ? 'text-danger' : 'text-info'); ?> text-danger">
                            
                            <?php echo e(ucfirst($style->subscription)); ?></span>
                        <span>
                            <a href="<?php echo e(route('styleDownload', $style)); ?>" class="text-info"><i class="fa fa-download"
                                    aria-hidden="true"></i>
                                Try</span></a>
                            <a href="<?php echo e(route('admin.style.edit', $style)); ?>" class="text-warning"><i class="fa fa-pen-square"
                                    aria-hidden="true"></i>
                                Edit</span></a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\stylusAddon\resources\views/admin/style/index.blade.php ENDPATH**/ ?>