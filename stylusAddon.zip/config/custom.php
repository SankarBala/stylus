<?php

return [
    'tel' => '01700000000',
    'address' => 'Unknown',
    'email' => 'info@test.com',
    'url' => 'https://test.com',
    'author' => 'Rafi',
];
